<?php
error_reporting(0); // Turn off all error reporting
ini_set('display_errors', '0'); // Do not display errors

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "excel_splitter";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>