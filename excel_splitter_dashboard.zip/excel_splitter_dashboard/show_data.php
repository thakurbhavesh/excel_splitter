<?php
require_once('header.php');
require_once('config.php');
require_once('vendor/autoload.php'); // Ensure you have ZipStream installed

// SQL query to select data from the 'files' table
$sql = "SELECT * FROM files";
$result = $conn->query($sql);

// Check if there was an error with the SQL query
if (!$result) {
    die("Error in SQL query: " . $conn->error);
}

// Handle truncation
if (isset($_POST['truncate'])) {
    if ($conn->query("TRUNCATE TABLE files")) {
        echo "<script>alert('Table truncated successfully');</script>";
    } else {
        echo "<script>alert('Error truncating table: " . $conn->error . "');</script>";
    }
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page
    exit();
}

// Handle ZIP download for selected files
if (isset($_POST['download_zip']) && !empty($_POST['selected_files'])) {
    require_once('vendor/autoload.php'); // Ensure ZipStream is included
    $zip = new ZipStream\ZipStream('selected_files.zip');
    
    foreach ($_POST['selected_files'] as $fileId) {
        $fileId = intval($fileId);
        $sql = "SELECT file_path, file_name FROM files WHERE id = $fileId";
        $fileResult = $conn->query($sql);

        if ($fileResult && $fileResult->num_rows > 0) {
            $file = $fileResult->fetch_assoc();
            $filePath = $file['file_path'];
            $fileName = $file['file_name'];

            if (file_exists($filePath)) {
                $zip->addFile($fileName, file_get_contents($filePath));
            } else {
                echo "<script>alert('File does not exist: $filePath');</script>";
            }
        } else {
            echo "<script>alert('Error retrieving file: $fileId');</script>";
        }
    }

    $zip->finish();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>File DataTable</title>
  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .table-primary { background-color: #007bff; color: white; }
    .table-secondary { background-color: #6c757d; color: white; }
  </style>
</head>
<body>

<div class="container mt-3">
  <h2 class="text-center">Show Data</h2>
  
  <!-- Buttons for actions -->
  <form method="POST" class="mb-3" id="actionForm">
    <button type="submit" name="truncate" class="btn btn-danger btn-sm" onclick="return confirmAction('truncate')">Truncate Table</button>
  </form>
  
  <table class="table table-striped" id="filesTable">
    <thead>
      <tr>
        <th>ID</th>
        <th>File Name</th>
        <th>File Type</th>
        <th>Download</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Check if there are results
      if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
          $filePath = htmlspecialchars($row["file_path"]);
          $fileName = htmlspecialchars($row["file_name"]);
          $fileType = htmlspecialchars(strtoupper($row["file_type"]));
          $createdAt = date('M-d-Y H:i:s ( l ) ', strtotime($row["created_at"]));
          $rowClass = ($fileType == 'PARENT') ? 'table-primary' : 'table-secondary';
          echo "<tr class='$rowClass'>";
          echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
          echo "<td>" . $fileName . "</td>";
          echo "<td><b>" . $fileType . "</b></td>";
          echo "<td><a href='$filePath' class='btn btn-success btn-sm' download><i class='fa fa-download' style='font-size:24px;color:orange'></i></a></td>";
          echo "<td>" . $createdAt . "</td>";
          echo "</tr>";
        }
      } else {
        echo "<tr><td colspan='6'>No results found</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
$(document).ready(function() {
  $('#filesTable').DataTable(); // Initialize DataTables on the table
});

// Confirmation function for truncation
function confirmAction(action) {
    if (action === 'truncate') {
        return confirm('Are you sure you want to truncate the entire table? This action cannot be undone.');
    }
    return false;
}
</script>

</body>
</html>

<?php
$conn->close();
?>
