<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excel Splitter Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .table-primary {
            background-color: #007bff;
            color: white;
        }

        .table-secondary {
            background-color: #6c757d;
            color: white;
        }
    </style>
    <style>
        label {
            font-weight: bolder;
        }

        table {
            font-size: 1rem;
            border-radius: .25rem;
        }

        thead th {
            background-color: #343a40;
            color: #fff;
        }

        tbody tr:nth-child(odd) {
            background-color: #f2f2f2;
        }

        tbody tr:hover {
            background-color: #e9ecef;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        a {
            text-decoration: none;
        }

        .download-icon {
            color: #007bff;
            font-size: 1.25rem;
        }

        .download-icon:hover {
            color: #0056b3;
        }

        .toast-container {
            z-index: 1050;
            /* Ensure toast is on top */
        }

        .styledemo {
            min-width: 500px !important;
            max-width: 1000px !important;
            margin: 0 auto;
            border: 1px solid black;
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand mx-5" href="#">Excel Splitter</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Upload Data</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="show_data.php">Show Data</a>
                </li>
            </ul>
        </div>
    </nav>