<?php
require_once('header.php');
?>

    <div class="container mt-5">
        <div class="row">
            <!-- Form Column (Visible when Upload Data is selected) -->
            <?php if (!isset($_GET['action']) || $_GET['action'] == 'upload') { ?>
            <div class="col-md-12">
                <h2 class="text-center">Excel Splitter Dashboard</h2>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="excelFile" class="form-label">Upload Excel File</label>
                        <input type="file" class="form-control" id="excelFile" name="excelFile" accept=".xls,.xlsx" required>
                    </div>
                    <div class="mb-3">
                        <label for="range" class="form-label">Select Number of Rows Per Sheet</label>
                        <input type="number" class="form-control" id="range" name="range" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label for="customName" class="form-label">Custom Name for Split Files</label>
                        <input type="text" class="form-control" id="customName" name="customName" placeholder="Enter custom file name" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Split Excel</button>
                </form>
            </div>
            
            <?php } ?>

           
        </div>
        <hr>
    </div>

    <!-- Toast Message Script -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#filesTable').DataTable();

            // Show the toast message
            var toastEl = document.querySelector('.toast');
            if (toastEl) {
                var toast = new bootstrap.Toast(toastEl, {
                    delay: 2000 // Toast will be visible for 2 seconds
                });
                toast.show();
            }
        });
    </script>
</body>
</html>

<?php
require 'config.php';

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
// use ZipArchive;

$showData = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['excelFile'])) {
    $file = $_FILES['excelFile']['tmp_name'];
    $rowsPerSheet = intval($_POST['range']);
    $customName = isset($_POST['customName']) ? trim($_POST['customName']) : 'split_file';

    try {
        $spreadsheet = IOFactory::load($file);
        $sheet = $spreadsheet->getActiveSheet();
        $highestRow = $sheet->getHighestRow();
        $columns = $sheet->getHighestColumn();

        $sheetIndex = 0;
        $currentRow = 1;

        $splitSpreadsheets = [];
        $parentFile = 'splits/' . $customName . '.xlsx';

        // Save the original file
        $writer = new Xlsx($spreadsheet);
        $writer->save($parentFile);

        // Insert parent file record into database
        $stmt = $conn->prepare("INSERT INTO files (file_name, file_path, file_type) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $parentName, $parentFile, $fileType);
        $parentName = basename($parentFile);
        $fileType = 'parent';
        $stmt->execute();

        while ($currentRow <= $highestRow) {
            $newSpreadsheet = new Spreadsheet();
            $newSheet = $newSpreadsheet->getActiveSheet();

            for ($i = 0; $i < $rowsPerSheet && $currentRow <= $highestRow; $i++, $currentRow++) {
                for ($col = 'A'; $col <= $columns; $col++) {
                    $value = $sheet->getCell("$col$currentRow")->getValue();
                    $newSheet->setCellValue("$col" . ($i + 1), $value);
                }
            }

            $splitSpreadsheets[] = $newSpreadsheet;
            $sheetIndex++;
        }

        // Save each sheet and create download links
        $zip = new ZipArchive();
        $zipFileName = 'splits/' . $customName . '_files.zip';

        if (!is_dir('splits')) {
            mkdir('splits', 0777, true);
        }

        if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $files = [];
            foreach ($splitSpreadsheets as $index => $splitSheet) {
                $writer = new Xlsx($splitSheet);
                $filename = 'splits/' . $customName . '_' . ($index + 1) . '.xlsx';
                $writer->save($filename);

                // Add the file to the ZIP
                $zip->addFile($filename, basename($filename));

                // Insert split file record into database
                $stmt->bind_param("sss", $fileName, $filePath, $fileType);
                $fileName = basename($filename);
                $filePath = $filename;
                $fileType = 'split';
                $stmt->execute();

                // Store file data for table
                $files[] = [
                    'name' => basename($filename),
                    'path' => $filename
                ];
            }
            $zip->close();

            // Show success toast message
            echo "<div class='toast-container position-fixed top-0 end-0 p-3 '>";
            echo "<div class='toast align-items-center text-white bg-success' role='alert' aria-live='assertive' aria-atomic='true'>";
            echo "<div class='d-flex'>";
            echo "<div class='toast-body'>Files split successfully!</div>";
            echo "<button type='button' class='btn-close btn-close-white me-2 m-auto' data-bs-dismiss='toast' aria-label='Close'></button>";
            echo "</div></div></div>";

            // Display parent file and split files
            echo "<div id='result' class='mt-4 styledemo'>";
            echo "<div class='alert alert-info mb-3'>Parent File: <a href='$parentFile' class='download-icon' download><i class='fas fa-download'></i></a></div>";
            echo "<div class='alert alert-secondary text-center mb-3'>Download all split files as a <a href='$zipFileName' class='btn btn-primary' download>ZIP file</a></div>";

            echo "<table id='filesTable' class='table table-striped'>";
            echo "<thead><tr><th>File Name</th><th>Download</th></tr></thead><tbody>";

            foreach ($files as $file) {
                echo "<tr><td>{$file['name']}</td>";
                echo "<td><a class='download-icon' href='{$file['path']}' download><i class='fas fa-download'></i></a></td></tr>";
            }

            echo "</tbody></table>";
            echo "</div>";

            $showData = true;

        } else {
            echo "<div class='alert alert-danger'>Error creating ZIP file.</div>";
        }

        $stmt->close();
        $conn->close();

    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error processing file: " . $e->getMessage() . "</div>";
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'show') {
    $showData = true;
    $result = $conn->query("SELECT * FROM files order by id desc");
}

?>

